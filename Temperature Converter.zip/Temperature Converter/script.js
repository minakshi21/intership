function convertTemperature() {
    const temperatureInput = document.getElementById("temperatureInput").value;
    const unitSelect = document.getElementById("unitSelect").value;
    const resultElement = document.getElementById("result");
    let convertedTemperature, unit;
  
    if (isNaN(temperatureInput)) {
      resultElement.textContent = "Please enter a valid number.";
      return;
    }
  
    const temperature = parseFloat(temperatureInput);
  
    if (unitSelect === "celsius") {
      convertedTemperature = (temperature * 9/5) + 32;
      unit = "Fahrenheit";
    } else if (unitSelect === "fahrenheit") {
      convertedTemperature = (temperature - 32) * 5/9;
      unit = "Celsius";
    } else if (unitSelect === "kelvin") {
      convertedTemperature = temperature - 273.15;
      unit = "Celsius";
    }
  
    resultElement.textContent = `Converted Temperature: ${convertedTemperature.toFixed(2)} ${unit}`;
  }
  