const pendingTasksList = document.getElementById("pendingTasksList");
const completedTasksList = document.getElementById("completedTasksList");
const newTaskInput = document.getElementById("newTaskInput");

function createTaskElement(taskText, isCompleted) {
  const li = document.createElement("li");
  li.innerText = taskText;

  if (isCompleted) {
    li.classList.add("completed");
  } else {
    const completeButton = document.createElement("button");
    completeButton.innerText = "Complete";
    completeButton.onclick = function () {
      completeTask(li);
    };
    li.appendChild(completeButton);
  }

  const editButton = document.createElement("button");
  editButton.innerText = "Edit";
  editButton.onclick = function () {
    editTask(li);
  };

  const deleteButton = document.createElement("button");
  deleteButton.innerText = "Delete";
  deleteButton.onclick = function () {
    deleteTask(li);
  };

  li.appendChild(editButton);
  li.appendChild(deleteButton);

  return li;
}

function addTask() {
  const taskText = newTaskInput.value.trim();
  if (taskText !== "") {
    const taskElement = createTaskElement(taskText, false);
    pendingTasksList.appendChild(taskElement);
    newTaskInput.value = "";
  }
}

function completeTask(taskElement) {
  taskElement.classList.add("completed");
  const completeButton = taskElement.querySelector("button");
  taskElement.removeChild(completeButton);
  completedTasksList.appendChild(taskElement);
}

function editTask(taskElement) {
  const taskText = taskElement.innerText;
  const newText = prompt("Edit task:", taskText);
  if (newText !== null && newText.trim() !== "") {
    taskElement.innerText = newText.trim();
  }
}

function deleteTask(taskElement) {
  taskElement.remove();
}
